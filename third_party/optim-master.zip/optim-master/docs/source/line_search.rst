.. Copyright (c) 2016-2023 Keith O'Hara

   Distributed under the terms of the Apache License, Version 2.0.

   The full license is in the file LICENSE, distributed with this software.

Line Search
===========

For effective line search in convex optimization problems, OptimLib uses the method of More and Thuente (1994).
