To launch this test open two different consoles:

In the first one launch: ./Registered writer (or Registered.exe writer on windows).
In the second one: ./Registered reader (or Registered.exe reader on windows).
