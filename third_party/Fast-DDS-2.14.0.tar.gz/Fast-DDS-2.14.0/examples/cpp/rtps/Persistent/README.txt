To launch this test open two different consoles:

In the first one launch: ./Persistent writer (or Persistent.exe writer on windows).
In the second one: ./Persistent reader (or Persistent.exe reader on windows).
