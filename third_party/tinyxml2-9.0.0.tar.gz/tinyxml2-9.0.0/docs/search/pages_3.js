var searchData=
[
  ['read_20attributes_20and_20text_20information_2e_285',['Read attributes and text information.',['../_example_4.html',1,'']]]
];
